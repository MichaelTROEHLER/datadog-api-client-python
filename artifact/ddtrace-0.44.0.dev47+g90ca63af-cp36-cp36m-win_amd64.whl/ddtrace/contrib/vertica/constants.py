# Service info
APP = "vertica"
