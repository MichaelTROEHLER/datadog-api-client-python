FRAMEWORK = "pytest"
KIND = "test"

HELP_MSG = "Enable tracing of pytest functions."
