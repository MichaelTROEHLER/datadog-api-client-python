DEFAULT_SERVICE = 'requests'
