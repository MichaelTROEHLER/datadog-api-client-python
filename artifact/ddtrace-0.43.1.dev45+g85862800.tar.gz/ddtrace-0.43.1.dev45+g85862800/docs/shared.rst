.. _setup documentation: https://docs.datadoghq.com/tracing/setup/python/

.. _official documentation: https://docs.datadoghq.com/tracing/visualization/

.. _development guide: https://github.com/datadog/dd-trace-py#development
