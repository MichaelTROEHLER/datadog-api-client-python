import sys

if __name__ == "__main__":
    assert sys.argv[1:] == ["foo", "bar"]
    print("Test success")
