from . import SpanTypes

# [TODO] Deprecated, remove when we remove AppTypes
TYPE = SpanTypes.CACHE

CMD = 'memcached.command'
SERVICE = 'memcached'
QUERY = 'memcached.query'
