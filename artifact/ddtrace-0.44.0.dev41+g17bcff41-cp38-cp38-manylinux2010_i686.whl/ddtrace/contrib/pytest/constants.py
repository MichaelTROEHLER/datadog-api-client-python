FRAMEWORK = "pytest"

HELP_MSG = "Enable tracing of pytest functions."
