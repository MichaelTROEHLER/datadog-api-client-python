from ddtrace import config

# pytest default settings
config._add("pytest", {})
